<!-- markdownlint-disable MD041 -->

```{include} ../README.md
:end-before: <!-- end-docs -->
```

```{toctree}
:maxdepth: 1

installation
examples/index
reference/index
license
contributing
authors
changelog
navigation
```
