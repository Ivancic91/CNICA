# API Reference

```{eval-rst}
.. currentmodule:: CNICA

.. autosummary::
   :toctree: generated/

   example_function
```
