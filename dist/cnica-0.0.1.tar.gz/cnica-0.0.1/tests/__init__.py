"""Unit test package for CNICA."""
